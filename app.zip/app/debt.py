from datetime import datetime
import psycopg2
import pandas as pd


def calculate_debts():
    try:
        conn = psycopg2.connect(
            dbname="energy",
            user="postgres",
            password="1Wizard1",
            host="localhost",
            port="5432"
        )
        cursor = conn.cursor()

        cursor.execute("SELECT id, full_name FROM abonents")
        abonents = cursor.fetchall()

        cursor.execute("SELECT id, abonent_id FROM meters")
        meters = cursor.fetchall()

        cursor.execute("SELECT meter_id, reading_date, value FROM readings ORDER BY reading_date")
        readings = cursor.fetchall()

        cursor.execute("SELECT start_date, value FROM tariffs ORDER BY start_date")
        tariffs = cursor.fetchall()

        cursor.execute("SELECT abonent_id, pay_date, amount FROM payments")
        payments = cursor.fetchall()

        cursor.close()
        conn.close()

        df_readings = pd.DataFrame(readings, columns=["meter_id", "reading_date", "value"])
        df_readings["reading_date"] = pd.to_datetime(df_readings["reading_date"])

        df_tariffs = pd.DataFrame(tariffs, columns=["start_date", "value"])
        df_tariffs["start_date"] = pd.to_datetime(df_tariffs["start_date"])

        df_payments = pd.DataFrame(payments, columns=["abonent_id", "pay_date", "amount"])
        df_payments["pay_date"] = pd.to_datetime(df_payments["pay_date"])

        df_meters = pd.DataFrame(meters, columns=["id", "abonent_id"])

        results = []

        for ab_id, ab_name in abonents:
            ab_meter_ids = df_meters[df_meters["abonent_id"] == ab_id]["id"].tolist()
            ab_readings = df_readings[df_readings["meter_id"].isin(ab_meter_ids)].sort_values("reading_date")

            if len(ab_readings) < 2:
                continue

            total_kwh = 0
            total_charge = 0

            for i in range(1, len(ab_readings)):
                diff = ab_readings.iloc[i]["value"] - ab_readings.iloc[i - 1]["value"]
                date = ab_readings.iloc[i]["reading_date"]
                tariff = df_tariffs[df_tariffs["start_date"] <= date].iloc[-1]
                total_kwh += diff
                total_charge += diff * tariff["value"]

            ab_payments = df_payments[df_payments["abonent_id"] == ab_id]
            total_payment = ab_payments["amount"].sum()
            debt = total_charge - total_payment

            results.append({
                "abonent_id": ab_id,
                "full_name": ab_name,
                "total_charge": round(total_charge, 2),
                "total_payment": round(total_payment, 2),
                "debt": round(debt, 2)
            })

        return results

    except Exception as e:
        print(f"Ошибка при расчёте задолженности: {e}")
        return []
