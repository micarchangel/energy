from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QTableWidget, QTableWidgetItem, QPushButton, QFileDialog, QMessageBox
)
import csv
import pandas as pd
from app.debt import calculate_debts


class DebtTab(QWidget):
    def __init__(self):
        super().__init__()
        self.layout = QVBoxLayout(self)

        self.table = QTableWidget()
        self.layout.addWidget(self.table)

        self.export_csv_btn = QPushButton("Экспорт в CSV")
        self.export_csv_btn.clicked.connect(self.export_to_csv)
        self.layout.addWidget(self.export_csv_btn)

        self.export_xlsx_btn = QPushButton("Экспорт в Excel")
        self.export_xlsx_btn.clicked.connect(self.export_to_xlsx)
        self.layout.addWidget(self.export_xlsx_btn)

        self.load_data()

    def load_data(self):
        debts = calculate_debts()
        self.table.setRowCount(len(debts))
        self.table.setColumnCount(5)
        self.table.setHorizontalHeaderLabels(
            ["ID абонента", "ФИО", "Сумма начислений", "Сумма оплат", "Задолженность"]
        )

        for row, item in enumerate(debts):
            self.table.setItem(row, 0, QTableWidgetItem(str(item["abonent_id"])))
            self.table.setItem(row, 1, QTableWidgetItem(item["full_name"]))
            self.table.setItem(row, 2, QTableWidgetItem(f"{item['total_charge']:.2f}"))
            self.table.setItem(row, 3, QTableWidgetItem(f"{item['total_payment']:.2f}"))
            self.table.setItem(row, 4, QTableWidgetItem(f"{item['debt']:.2f}"))

    def export_to_csv(self):
        path, _ = QFileDialog.getSaveFileName(self, "Сохранить в CSV", "", "CSV Files (*.csv)")
        if path:
            with open(path, mode='w', newline='', encoding='utf-8') as file:
                writer = csv.writer(file)
                headers = [self.table.horizontalHeaderItem(i).text() for i in range(self.table.columnCount())]
                writer.writerow(headers)
                for row in range(self.table.rowCount()):
                    writer.writerow([
                        self.table.item(row, col).text() if self.table.item(row, col) else ""
                        for col in range(self.table.columnCount())
                    ])
            QMessageBox.information(self, "Экспорт", "Файл CSV успешно сохранён!")

    def export_to_xlsx(self):
        path, _ = QFileDialog.getSaveFileName(self, "Сохранить в Excel", "", "Excel Files (*.xlsx)")
        if path:
            data = []
            for row in range(self.table.rowCount()):
                row_data = [
                    self.table.item(row, col).text() if self.table.item(row, col) else ""
                    for col in range(self.table.columnCount())
                ]
                data.append(row_data)
            df = pd.DataFrame(data, columns=[self.table.horizontalHeaderItem(i).text() for i in range(self.table.columnCount())])
            df.to_excel(path, index=False)
            QMessageBox.information(self, "Экспорт", "Файл Excel успешно сохранён!")
