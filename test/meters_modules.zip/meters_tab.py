
from PyQt6.QtWidgets import QWidget, QVBoxLayout, QTableWidget, QPushButton, QHBoxLayout, QTableWidgetItem, QDialog, QLabel, QLineEdit, QComboBox, QDateEdit, QMessageBox
from PyQt6.QtCore import Qt, QDate
from meters import get_all_meters, add_meter, update_meter, delete_meter, get_abonents
import psycopg2
import datetime

class MetersTab(QWidget):
    def __init__(self, conn):
        super().__init__()
        self.conn = conn
        self.layout = QVBoxLayout()
        self.table = QTableWidget()
        self.layout.addWidget(self.table)

        button_layout = QHBoxLayout()
        add_btn = QPushButton("Добавить")
        edit_btn = QPushButton("Редактировать")
        delete_btn = QPushButton("Удалить")

        add_btn.clicked.connect(self.add_meter_dialog)
        edit_btn.clicked.connect(self.edit_meter_dialog)
        delete_btn.clicked.connect(self.delete_meter)

        button_layout.addWidget(add_btn)
        button_layout.addWidget(edit_btn)
        button_layout.addWidget(delete_btn)
        self.layout.addLayout(button_layout)
        self.setLayout(self.layout)
        self.load_data()

    def load_data(self):
        self.table.setColumnCount(5)
        self.table.setHorizontalHeaderLabels(["ID", "Серийный номер", "Тип", "Дата установки", "Абонент"])
        self.table.setRowCount(0)
        for row_data in get_all_meters(self.conn):
            row_idx = self.table.rowCount()
            self.table.insertRow(row_idx)
            for col_idx, value in enumerate(row_data):
                self.table.setItem(row_idx, col_idx, QTableWidgetItem(str(value)))

    def add_meter_dialog(self):
        dialog = MeterFormDialog(self.conn)
        if dialog.exec():
            self.load_data()

    def edit_meter_dialog(self):
        selected = self.table.currentRow()
        if selected == -1:
            QMessageBox.warning(self, "Ошибка", "Выберите запись для редактирования.")
            return
        meter_id = int(self.table.item(selected, 0).text())
        serial_number = self.table.item(selected, 1).text()
        meter_type = self.table.item(selected, 2).text()
        install_date = self.table.item(selected, 3).text()
        abonent_name = self.table.item(selected, 4).text()

        dialog = MeterFormDialog(self.conn, meter_id, serial_number, meter_type, install_date, abonent_name)
        if dialog.exec():
            self.load_data()

    def delete_meter(self):
        selected = self.table.currentRow()
        if selected == -1:
            QMessageBox.warning(self, "Ошибка", "Выберите запись для удаления.")
            return
        meter_id = int(self.table.item(selected, 0).text())
        confirm = QMessageBox.question(self, "Подтверждение", "Удалить выбранный счётчик?",
                                       QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if confirm == QMessageBox.StandardButton.Yes:
            delete_meter(self.conn, meter_id)
            self.load_data()

class MeterFormDialog(QDialog):
    def __init__(self, conn, meter_id=None, serial_number="", meter_type="", install_date="", abonent_name=""):
        super().__init__()
        self.conn = conn
        self.setWindowTitle("Форма счётчика")
        self.layout = QVBoxLayout()
        self.serial_input = QLineEdit(serial_number)
        self.type_input = QLineEdit(meter_type)
        self.date_input = QDateEdit()
        self.date_input.setCalendarPopup(True)
        self.date_input.setDate(QDate.fromString(install_date, "yyyy-MM-dd") if install_date else QDate.currentDate())
        self.abonent_combo = QComboBox()
        self.abonent_map = {}

        for aid, name in get_abonents(conn):
            self.abonent_combo.addItem(name)
            self.abonent_map[name] = aid

        if abonent_name:
            self.abonent_combo.setCurrentText(abonent_name)

        self.layout.addWidget(QLabel("Серийный номер:"))
        self.layout.addWidget(self.serial_input)
        self.layout.addWidget(QLabel("Тип:"))
        self.layout.addWidget(self.type_input)
        self.layout.addWidget(QLabel("Дата установки:"))
        self.layout.addWidget(self.date_input)
        self.layout.addWidget(QLabel("Абонент:"))
        self.layout.addWidget(self.abonent_combo)

        save_btn = QPushButton("Сохранить")
        save_btn.clicked.connect(self.save)
        self.layout.addWidget(save_btn)
        self.setLayout(self.layout)
        self.meter_id = meter_id

    def save(self):
        serial = self.serial_input.text()
        mtype = self.type_input.text()
        date = self.date_input.date().toString("yyyy-MM-dd")
        abonent_id = self.abonent_map[self.abonent_combo.currentText()]

        if self.meter_id:
            update_meter(self.conn, self.meter_id, serial, mtype, date, abonent_id)
        else:
            add_meter(self.conn, serial, mtype, date, abonent_id)
        self.accept()
