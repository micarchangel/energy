
import psycopg2

def get_all_meters(conn):
    with conn.cursor() as cur:
        cur.execute("""
            SELECT m.id, m.serial_number, m.type, m.install_date, a.full_name
            FROM meters m
            JOIN abonents a ON m.abonent_id = a.id
            ORDER BY m.id
        """)
        return cur.fetchall()

def add_meter(conn, serial_number, meter_type, install_date, abonent_id):
    with conn.cursor() as cur:
        cur.execute("""
            INSERT INTO meters (serial_number, type, install_date, abonent_id)
            VALUES (%s, %s, %s, %s)
        """, (serial_number, meter_type, install_date, abonent_id))
    conn.commit()

def update_meter(conn, meter_id, serial_number, meter_type, install_date, abonent_id):
    with conn.cursor() as cur:
        cur.execute("""
            UPDATE meters
            SET serial_number = %s, type = %s, install_date = %s, abonent_id = %s
            WHERE id = %s
        """, (serial_number, meter_type, install_date, abonent_id, meter_id))
    conn.commit()

def delete_meter(conn, meter_id):
    with conn.cursor() as cur:
        cur.execute("DELETE FROM meters WHERE id = %s", (meter_id,))
    conn.commit()

def get_abonents(conn):
    with conn.cursor() as cur:
        cur.execute("SELECT id, full_name FROM abonents ORDER BY full_name")
        return cur.fetchall()
